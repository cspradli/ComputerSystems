#ifndef philosopher_h
#define philosopher_h


void create_5_philosophers();

void kill_5_philosophers();

void philosopher_algorithm(int num);

void philosopher_algorithm_cr(int num);

#endif //philosopher_h
